module SectorsHelper
end
