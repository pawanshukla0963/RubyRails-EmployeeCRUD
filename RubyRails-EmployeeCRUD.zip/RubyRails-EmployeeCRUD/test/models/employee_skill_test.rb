require 'test_helper'

class EmployeeSkillTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
